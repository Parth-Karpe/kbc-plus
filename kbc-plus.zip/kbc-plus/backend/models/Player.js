const mongoose = require('mongoose');

const PlayerSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  highScore: { type: Number, default: 0 },
  levelReached: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Player', PlayerSchema);
