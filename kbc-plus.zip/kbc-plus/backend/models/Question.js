const mongoose = require('mongoose');

const QuestionSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: { type: [String], required: true }, // exactly 4 options
  correctAnswer: { type: String, required: true }, // must match one of options
  level: { type: Number, required: true, min: 1, max: 10 }
});

module.exports = mongoose.model('Question', QuestionSchema);
