const mongoose = require('mongoose');
const Question = require('./models/Question');
require('dotenv').config();

const questions = [
  // Level 1 - Very Easy
  { level: 1, question: "What is the capital of India?", options: ["Mumbai", "New Delhi", "Kolkata", "Chennai"], correctAnswer: "New Delhi" },
  { level: 1, question: "How many days are in a week?", options: ["5", "6", "7", "8"], correctAnswer: "7" },
  { level: 1, question: "Which planet is known as the Red Planet?", options: ["Jupiter", "Saturn", "Mars", "Venus"], correctAnswer: "Mars" },

  // Level 2 - Easy
  { level: 2, question: "What is 15 × 4?", options: ["45", "50", "60", "55"], correctAnswer: "60" },
  { level: 2, question: "Who wrote Romeo and Juliet?", options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"], correctAnswer: "William Shakespeare" },
  { level: 2, question: "What is the chemical symbol for water?", options: ["WA", "H2O", "HO", "O2H"], correctAnswer: "H2O" },

  // Level 3 - Easy-Medium
  { level: 3, question: "Which country invented cricket?", options: ["Australia", "India", "England", "South Africa"], correctAnswer: "England" },
  { level: 3, question: "What does CPU stand for?", options: ["Central Processing Unit", "Computer Personal Unit", "Central Power Unit", "Core Processing Unit"], correctAnswer: "Central Processing Unit" },
  { level: 3, question: "How many bones are in the adult human body?", options: ["186", "206", "256", "196"], correctAnswer: "206" },

  // Level 4 - Medium
  { level: 4, question: "Who is known as the Father of Computers?", options: ["Alan Turing", "Bill Gates", "Charles Babbage", "Steve Jobs"], correctAnswer: "Charles Babbage" },
  { level: 4, question: "What is the largest ocean on Earth?", options: ["Atlantic", "Indian", "Arctic", "Pacific"], correctAnswer: "Pacific" },
  { level: 4, question: "In which year did India get independence?", options: ["1945", "1947", "1950", "1942"], correctAnswer: "1947" },

  // Level 5 - Medium
  { level: 5, question: "What is the square root of 144?", options: ["11", "12", "13", "14"], correctAnswer: "12" },
  { level: 5, question: "Which gas do plants absorb from the atmosphere?", options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"], correctAnswer: "Carbon Dioxide" },
  { level: 5, question: "What is the speed of light (approx)?", options: ["2 × 10^8 m/s", "3 × 10^8 m/s", "4 × 10^8 m/s", "1 × 10^8 m/s"], correctAnswer: "3 × 10^8 m/s" },

  // Level 6 - Medium-Hard
  { level: 6, question: "Which programming language is known as the backbone of the web?", options: ["Python", "Java", "JavaScript", "C++"], correctAnswer: "JavaScript" },
  { level: 6, question: "What is the powerhouse of the cell?", options: ["Nucleus", "Ribosome", "Mitochondria", "Golgi Body"], correctAnswer: "Mitochondria" },
  { level: 6, question: "Who painted the Mona Lisa?", options: ["Michelangelo", "Raphael", "Leonardo da Vinci", "Donatello"], correctAnswer: "Leonardo da Vinci" },

  // Level 7 - Hard
  { level: 7, question: "What does HTTP stand for?", options: ["HyperText Transfer Protocol", "High Transfer Text Protocol", "HyperText Transit Protocol", "Home Text Transfer Protocol"], correctAnswer: "HyperText Transfer Protocol" },
  { level: 7, question: "Which element has atomic number 79?", options: ["Silver", "Platinum", "Gold", "Copper"], correctAnswer: "Gold" },
  { level: 7, question: "Who proposed the theory of relativity?", options: ["Isaac Newton", "Niels Bohr", "Albert Einstein", "Max Planck"], correctAnswer: "Albert Einstein" },

  // Level 8 - Hard
  { level: 8, question: "What is the time complexity of binary search?", options: ["O(n)", "O(n²)", "O(log n)", "O(n log n)"], correctAnswer: "O(log n)" },
  { level: 8, question: "Which country has the most natural lakes?", options: ["Russia", "USA", "Canada", "Brazil"], correctAnswer: "Canada" },
  { level: 8, question: "What is the full form of SQL?", options: ["Structured Query Language", "Simple Query Language", "Standard Query Logic", "Structured Question Language"], correctAnswer: "Structured Query Language" },

  // Level 9 - Very Hard
  { level: 9, question: "Who invented the World Wide Web?", options: ["Bill Gates", "Tim Berners-Lee", "Vint Cerf", "Steve Jobs"], correctAnswer: "Tim Berners-Lee" },
  { level: 9, question: "What is the Heisenberg Uncertainty Principle about?", options: ["Speed of light", "Position and momentum of particles", "Energy of photons", "Gravitational waves"], correctAnswer: "Position and momentum of particles" },
  { level: 9, question: "In which year was the first iPhone released?", options: ["2005", "2006", "2007", "2008"], correctAnswer: "2007" },

  // Level 10 - Expert
  { level: 10, question: "What does 'idempotent' mean in REST APIs?", options: ["Request changes data every time", "Same request produces same result", "Request requires authentication", "Request is encrypted"], correctAnswer: "Same request produces same result" },
  { level: 10, question: "Which data structure uses LIFO principle?", options: ["Queue", "Stack", "Heap", "Tree"], correctAnswer: "Stack" },
  { level: 10, question: "What is the CAP theorem in distributed systems?", options: ["Consistency, Availability, Partition Tolerance", "Cache, Access, Performance", "Concurrency, Atomicity, Persistence", "Compression, Authentication, Privacy"], correctAnswer: "Consistency, Availability, Partition Tolerance" },
];

async function seed() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/kbcplus');
  await Question.deleteMany({});
  await Question.insertMany(questions);
  console.log(`✅ Seeded ${questions.length} questions successfully!`);
  mongoose.disconnect();
}

seed().catch(console.error);
