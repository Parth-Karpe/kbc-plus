const express = require('express');
const router = express.Router();
const Player = require('../models/Player');

// GET leaderboard - top 10
router.get('/', async (req, res) => {
  try {
    const players = await Player.find().sort({ highScore: -1 }).limit(10);
    res.json(players);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST save/update player score after game (Create or Update)
router.post('/', async (req, res) => {
  try {
    const { name, score, level } = req.body;
    let player = await Player.findOne({ name });
    if (player) {
      // Update only if new score is higher
      if (score > player.highScore) {
        player.highScore = score;
        player.levelReached = level;
        await player.save();
      }
      return res.json(player);
    }
    // Create new player
    const newPlayer = new Player({ name, highScore: score, levelReached: level });
    await newPlayer.save();
    res.status(201).json(newPlayer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE player
router.delete('/:id', async (req, res) => {
  try {
    await Player.findByIdAndDelete(req.params.id);
    res.json({ message: '✅ Player deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
