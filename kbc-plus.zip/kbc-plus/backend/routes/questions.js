const express = require('express');
const router = express.Router();
const Question = require('../models/Question');

// GET all questions (admin view)
router.get('/', async (req, res) => {
  try {
    const questions = await Question.find().sort({ level: 1 });
    res.json(questions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET questions by level (used during game)
router.get('/level/:level', async (req, res) => {
  try {
    const questions = await Question.find({ level: req.params.level });
    if (!questions.length) return res.status(404).json({ error: 'No questions found for this level' });
    // Return a random one
    const random = questions[Math.floor(Math.random() * questions.length)];
    res.json(random);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST add a new question (Create)
router.post('/', async (req, res) => {
  try {
    const { question, options, correctAnswer, level } = req.body;
    if (options.length !== 4) return res.status(400).json({ error: 'Exactly 4 options required' });
    if (!options.includes(correctAnswer)) return res.status(400).json({ error: 'Correct answer must be one of the options' });
    const newQuestion = new Question({ question, options, correctAnswer, level });
    await newQuestion.save();
    res.status(201).json(newQuestion);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update a question (Update)
router.put('/:id', async (req, res) => {
  try {
    const updated = await Question.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ error: 'Question not found' });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE a question (Delete)
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Question.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Question not found' });
    res.json({ message: '✅ Question deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
