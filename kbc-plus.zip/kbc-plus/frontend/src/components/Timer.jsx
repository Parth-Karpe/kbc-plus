import React, { useEffect, useState } from 'react';

export default function Timer({ duration, onTimeUp, frozen, reset }) {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    setTimeLeft(duration);
  }, [reset, duration]);

  useEffect(() => {
    if (frozen) return;
    if (timeLeft <= 0) { onTimeUp(); return; }
    const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, frozen, onTimeUp]);

  const pct = (timeLeft / duration) * 100;
  const isRed = timeLeft <= 5;
  const color = isRed ? '#e53e3e' : timeLeft <= 10 ? '#dd6b20' : '#FFD700';
  const r = 36, circ = 2 * Math.PI * r;

  return (
    <div style={styles.wrapper}>
      <svg width="90" height="90" style={{ transform: 'rotate(-90deg)' }}>
        <circle cx="45" cy="45" r={r} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
        <circle
          cx="45" cy="45" r={r} fill="none"
          stroke={color} strokeWidth="6"
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - pct / 100)}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.9s linear, stroke 0.3s' }}
        />
      </svg>
      <span style={{ ...styles.number, color, animation: isRed ? 'pulse 0.5s infinite' : 'none' }}>
        {timeLeft}
      </span>
      {frozen && <span style={styles.frozenBadge}>⏸ FROZEN</span>}
      <style>{`@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }`}</style>
    </div>
  );
}

const styles = {
  wrapper: {
    position: 'relative',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: 90, height: 90,
  },
  number: {
    position: 'absolute',
    fontSize: '1.6rem',
    fontWeight: 700,
    fontFamily: 'Cinzel, serif',
  },
  frozenBadge: {
    position: 'absolute',
    bottom: -20,
    fontSize: '0.65rem',
    color: '#63b3ed',
    letterSpacing: 1,
    whiteSpace: 'nowrap',
  },
};
