import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Timer from '../components/Timer';

const PRIZE_LADDER = [
  { level: 1,  points: 100,      safe: false },
  { level: 2,  points: 200,      safe: false },
  { level: 3,  points: 500,      safe: true  },
  { level: 4,  points: 1000,     safe: false },
  { level: 5,  points: 2000,     safe: false },
  { level: 6,  points: 4000,     safe: true  },
  { level: 7,  points: 8000,     safe: false },
  { level: 8,  points: 16000,    safe: false },
  { level: 9,  points: 32000,    safe: true  },
  { level: 10, points: 100000,   safe: false },
];

const TIMER_DURATION = (level) => level <= 4 ? 30 : level <= 8 ? 20 : 15;

export default function Game() {
  const navigate = useNavigate();
  const playerName = localStorage.getItem('playerName') || 'Player';

  const [level, setLevel] = useState(1);
  const [question, setQuestion] = useState(null);
  const [visibleOptions, setVisibleOptions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [status, setStatus] = useState('playing'); // playing | correct | wrong | gameover | won | quit
  const [score, setScore] = useState(0);
  const [safeScore, setSafeScore] = useState(0);
  const [lifelines, setLifelines] = useState({ removeWeakest: true, timeFreeze: true, flipQuestion: true });
  const [frozen, setFrozen] = useState(false);
  const [timerReset, setTimerReset] = useState(0);
  const [loading, setLoading] = useState(true);
  const [answerRevealed, setAnswerRevealed] = useState(false);

  const fetchQuestion = useCallback(async (lvl) => {
    setLoading(true);
    setSelected(null);
    setAnswerRevealed(false);
    setFrozen(false);
    try {
      const res = await axios.get(`/api/questions/level/${lvl}`);
      setQuestion(res.data);
      setVisibleOptions([...res.data.options]);
      setTimerReset(r => r + 1);
    } catch {
      alert('No question found for this level! Make sure you seeded the database.');
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchQuestion(1); }, [fetchQuestion]);

  const saveScore = async (finalScore, finalLevel) => {
    try {
      await axios.post('/api/players', { name: playerName, score: finalScore, level: finalLevel });
    } catch (e) { console.error(e); }
  };

  const handleAnswer = (option) => {
    if (selected || answerRevealed) return;
    setSelected(option);
    setAnswerRevealed(true);
    setFrozen(true); // stop timer

    setTimeout(() => {
      if (option === question.correctAnswer) {
        const newScore = PRIZE_LADDER[level - 1].points;
        setScore(newScore);
        if (PRIZE_LADDER[level - 1].safe) setSafeScore(newScore);

        if (level === 10) {
          setStatus('won');
          saveScore(newScore, level);
        } else {
          setStatus('correct');
          setTimeout(() => {
            setStatus('playing');
            setLevel(l => l + 1);
            fetchQuestion(level + 1);
          }, 1500);
        }
      } else {
        setStatus('wrong');
        saveScore(safeScore, level - 1);
      }
    }, 1200);
  };

  const handleTimeUp = useCallback(() => {
    if (answerRevealed) return;
    setAnswerRevealed(true);
    setStatus('wrong');
    saveScore(safeScore, level - 1);
  }, [answerRevealed, safeScore, level]);

  const handleQuit = () => {
    setStatus('quit');
    saveScore(score, level - 1);
  };

  // --- Lifelines ---
  const useRemoveWeakest = () => {
    if (!lifelines.removeWeakest || answerRevealed) return;
    const wrong = visibleOptions.filter(o => o !== question.correctAnswer);
    const toRemove = wrong[0]; // remove first wrong option
    setVisibleOptions(visibleOptions.filter(o => o !== toRemove));
    setLifelines(l => ({ ...l, removeWeakest: false }));
  };

  const useTimeFreeze = () => {
    if (!lifelines.timeFreeze || frozen) return;
    setFrozen(true);
    setLifelines(l => ({ ...l, timeFreeze: false }));
    setTimeout(() => setFrozen(false), 15000);
  };

  const useFlipQuestion = async () => {
    if (!lifelines.flipQuestion) return;
    setLifelines(l => ({ ...l, flipQuestion: false }));
    await fetchQuestion(level);
  };

  const getOptionStyle = (option) => {
    const base = { ...styles.option };
    if (!answerRevealed) return selected === option ? { ...base, ...styles.optionSelected } : base;
    if (option === question.correctAnswer) return { ...base, ...styles.optionCorrect };
    if (option === selected) return { ...base, ...styles.optionWrong };
    return { ...base, opacity: 0.4 };
  };

  if (status === 'wrong' || status === 'quit' || status === 'won') {
    const won = status === 'won';
    const quit = status === 'quit';
    const finalScore = won ? PRIZE_LADDER[9].points : quit ? score : safeScore;
    return (
      <div style={styles.container}>
        <div style={styles.gameoverCard}>
          <div style={{ fontSize: 72 }}>{won ? '🏆' : quit ? '🚪' : '💀'}</div>
          <h1 style={{ ...styles.gameoverTitle, color: won ? '#FFD700' : quit ? '#dd6b20' : '#e53e3e' }}>
            {won ? 'YOU WON!' : quit ? 'You Quit' : 'Wrong Answer!'}
          </h1>
          <p style={styles.gameoverName}>{playerName}</p>
          <div style={styles.scoreBox}>
            <p style={styles.scoreLabel}>{won ? 'PRIZE' : quit ? 'TAKE HOME' : 'SAFE AMOUNT'}</p>
            <p style={styles.scoreValue}>₹ {finalScore.toLocaleString()}</p>
          </div>
          {!won && !quit && safeScore > 0 && (
            <p style={{ color: '#a0aec0', marginBottom: 16, fontSize: '0.9rem' }}>
              Safe zone amount: ₹{safeScore.toLocaleString()}
            </p>
          )}
          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            <button className="btn btn-primary" onClick={() => { localStorage.removeItem('playerName'); navigate('/'); }}>
              Play Again
            </button>
            <button className="btn" onClick={() => navigate('/leaderboard')}>🏆 Leaderboard</button>
          </div>
        </div>
      </div>
    );
  }

  if (loading || !question) return (
    <div style={{ ...styles.container, justifyContent: 'center' }}>
      <p style={{ color: '#FFD700', fontSize: '1.5rem', letterSpacing: 4 }}>Loading...</p>
    </div>
  );

  return (
    <div style={styles.container}>
      {/* Left: Prize Ladder */}
      <div style={styles.ladder}>
        {[...PRIZE_LADDER].reverse().map(({ level: l, points, safe }) => (
          <div key={l} style={{
            ...styles.ladderRow,
            background: l === level ? 'rgba(255,215,0,0.2)' : 'transparent',
            border: l === level ? '1px solid #FFD700' : '1px solid transparent',
            color: safe ? '#FFD700' : '#fff',
            fontWeight: safe || l === level ? 700 : 400,
          }}>
            <span style={{ opacity: 0.6, fontSize: '0.75rem' }}>Q{l}</span>
            <span>₹{points.toLocaleString()}</span>
            {safe && <span style={{ fontSize: '0.65rem', color: '#68d391' }}>✅</span>}
          </div>
        ))}
      </div>

      {/* Center: Game */}
      <div style={styles.center}>
        <div style={styles.header}>
          <p style={styles.playerName}>👤 {playerName}</p>
          <Timer duration={TIMER_DURATION(level)} onTimeUp={handleTimeUp} frozen={frozen} reset={timerReset} />
          <p style={styles.scoreDisplay}>₹{score.toLocaleString()}</p>
        </div>

        <div style={styles.questionBox}>
          <p style={styles.levelTag}>Level {level} • Q{level}</p>
          <p style={styles.questionText}>{question.question}</p>
        </div>

        <div style={styles.optionsGrid}>
          {visibleOptions.map((opt, i) => (
            <button key={i} style={getOptionStyle(opt)} onClick={() => handleAnswer(opt)} disabled={!!selected}>
              <span style={styles.optLabel}>{['A', 'B', 'C', 'D'][question.options.indexOf(opt)]}</span>
              {opt}
            </button>
          ))}
        </div>

        {/* Lifelines */}
        <div style={styles.lifelines}>
          <button style={{ ...styles.lifeline, opacity: lifelines.removeWeakest ? 1 : 0.3 }}
            onClick={useRemoveWeakest} disabled={!lifelines.removeWeakest || !!selected}>
            ❌ Remove Weakest
          </button>
          <button style={{ ...styles.lifeline, opacity: lifelines.timeFreeze ? 1 : 0.3 }}
            onClick={useTimeFreeze} disabled={!lifelines.timeFreeze}>
            ⏸️ Time Freeze
          </button>
          <button style={{ ...styles.lifeline, opacity: lifelines.flipQuestion ? 1 : 0.3 }}
            onClick={useFlipQuestion} disabled={!lifelines.flipQuestion || !!selected}>
            🔁 Flip Question
          </button>
        </div>

        <button className="btn" style={{ marginTop: 16, borderColor: '#dd6b20', color: '#dd6b20' }} onClick={handleQuit}>
          🚪 Quit & Take ₹{score.toLocaleString()}
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    background: 'radial-gradient(ellipse at center, #0d1b4b 0%, #0a0a2e 80%)',
    padding: 20,
    gap: 20,
  },
  ladder: {
    width: 160,
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    alignSelf: 'flex-start',
    marginTop: 20,
  },
  ladderRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '4px 10px',
    borderRadius: 4,
    fontSize: '0.85rem',
    gap: 4,
  },
  center: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    maxWidth: 680,
    margin: '0 auto',
  },
  header: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  playerName: { color: '#FFD700', fontSize: '1rem', fontWeight: 600 },
  scoreDisplay: { color: '#FFD700', fontSize: '1.1rem', fontWeight: 700 },
  questionBox: {
    background: 'rgba(255,215,0,0.07)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 12,
    padding: '28px 32px',
    width: '100%',
    marginBottom: 24,
    textAlign: 'center',
    boxShadow: '0 0 30px rgba(255,215,0,0.05)',
  },
  levelTag: { color: '#FFD700', fontSize: '0.75rem', letterSpacing: 3, marginBottom: 12, opacity: 0.7 },
  questionText: { fontSize: '1.25rem', lineHeight: 1.6, color: '#fff', fontWeight: 500 },
  optionsGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 12,
    width: '100%',
    marginBottom: 20,
  },
  option: {
    padding: '14px 20px',
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 8,
    color: '#fff',
    cursor: 'pointer',
    fontFamily: 'Rajdhani, sans-serif',
    fontSize: '1rem',
    fontWeight: 500,
    textAlign: 'left',
    display: 'flex',
    gap: 12,
    alignItems: 'center',
    transition: 'all 0.15s',
  },
  optionSelected: {
    background: 'rgba(255,165,0,0.2)',
    border: '1px solid orange',
  },
  optionCorrect: {
    background: 'rgba(56,161,105,0.3)',
    border: '1px solid #38a169',
  },
  optionWrong: {
    background: 'rgba(229,62,62,0.3)',
    border: '1px solid #e53e3e',
  },
  optLabel: {
    background: 'rgba(255,215,0,0.2)',
    color: '#FFD700',
    borderRadius: 4,
    padding: '2px 8px',
    fontSize: '0.85rem',
    fontWeight: 700,
    minWidth: 24,
    textAlign: 'center',
  },
  lifelines: {
    display: 'flex',
    gap: 10,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  lifeline: {
    padding: '8px 16px',
    background: 'rgba(255,215,0,0.08)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 6,
    color: '#FFD700',
    cursor: 'pointer',
    fontFamily: 'Rajdhani, sans-serif',
    fontSize: '0.85rem',
    fontWeight: 600,
    letterSpacing: 1,
    transition: 'all 0.2s',
  },
  gameoverCard: {
    margin: 'auto',
    background: 'rgba(255,215,0,0.05)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 16,
    padding: '48px 40px',
    textAlign: 'center',
    maxWidth: 420,
    width: '100%',
    boxShadow: '0 0 60px rgba(255,215,0,0.1)',
  },
  gameoverTitle: { fontSize: '2.5rem', margin: '12px 0', letterSpacing: 4 },
  gameoverName: { color: '#a0aec0', marginBottom: 24, letterSpacing: 2 },
  scoreBox: {
    background: 'rgba(255,215,0,0.1)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 8,
    padding: '20px',
    marginBottom: 8,
  },
  scoreLabel: { color: '#a0aec0', fontSize: '0.75rem', letterSpacing: 3, marginBottom: 8 },
  scoreValue: { color: '#FFD700', fontSize: '2.5rem', fontFamily: 'Cinzel, serif', fontWeight: 700 },
};
