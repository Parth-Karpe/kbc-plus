import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleStart = () => {
    if (!name.trim()) return alert('Please enter your name!');
    localStorage.setItem('playerName', name.trim());
    navigate('/game');
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <div style={styles.logo}>🎯</div>
        <h1 style={styles.title}>KBC+</h1>
        <p style={styles.subtitle}>Kaun Banega Crorepati</p>
        <p style={styles.tagline}>New lifelines. Bigger stakes. Are you ready?</p>

        <div style={styles.inputGroup}>
          <input
            style={styles.input}
            type="text"
            placeholder="Enter your name..."
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleStart()}
            maxLength={20}
          />
          <button className="btn btn-primary" style={styles.startBtn} onClick={handleStart}>
            Start Game
          </button>
        </div>

        <button className="btn" style={{ marginTop: 16 }} onClick={() => navigate('/leaderboard')}>
          🏆 Leaderboard
        </button>

        <div style={styles.lifelineHint}>
          <p style={styles.hintTitle}>New Lifelines in KBC+</p>
          <div style={styles.hints}>
            <span>❌ Remove Weakest</span>
            <span>⏸️ Time Freeze</span>
            <span>🔁 Flip Question</span>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'radial-gradient(ellipse at center, #0d1b4b 0%, #0a0a2e 70%)',
    padding: 20,
  },
  card: {
    background: 'rgba(255,215,0,0.05)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 16,
    padding: '48px 40px',
    textAlign: 'center',
    maxWidth: 480,
    width: '100%',
    boxShadow: '0 0 60px rgba(255,215,0,0.1)',
  },
  logo: { fontSize: 64, marginBottom: 8 },
  title: {
    fontSize: '3.5rem',
    color: '#FFD700',
    letterSpacing: 8,
    marginBottom: 4,
  },
  subtitle: {
    color: '#a0aec0',
    fontSize: '0.9rem',
    letterSpacing: 3,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  tagline: {
    color: '#FFD700',
    fontSize: '1rem',
    marginBottom: 32,
    opacity: 0.8,
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  input: {
    padding: '14px 20px',
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,215,0,0.4)',
    borderRadius: 8,
    color: '#fff',
    fontSize: '1.1rem',
    fontFamily: 'Rajdhani, sans-serif',
    outline: 'none',
    textAlign: 'center',
    letterSpacing: 2,
  },
  startBtn: { fontSize: '1.1rem', padding: '14px 28px' },
  lifelineHint: {
    marginTop: 32,
    padding: '16px',
    background: 'rgba(255,215,0,0.05)',
    borderRadius: 8,
    border: '1px solid rgba(255,215,0,0.15)',
  },
  hintTitle: {
    color: '#FFD700',
    fontSize: '0.8rem',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  hints: {
    display: 'flex',
    justifyContent: 'space-around',
    color: '#a0aec0',
    fontSize: '0.85rem',
  },
};
