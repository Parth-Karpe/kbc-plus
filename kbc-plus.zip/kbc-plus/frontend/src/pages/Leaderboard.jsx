import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const MEDALS = ['🥇', '🥈', '🥉'];

export default function Leaderboard() {
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/api/players')
      .then(res => { setPlayers(res.data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this player from leaderboard?')) return;
    await axios.delete(`/api/players/${id}`);
    setPlayers(players.filter(p => p._id !== id));
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>🏆 Leaderboard</h1>
        <p style={styles.subtitle}>Top 10 Players</p>

        {loading ? (
          <p style={{ color: '#a0aec0', textAlign: 'center', padding: 40 }}>Loading...</p>
        ) : players.length === 0 ? (
          <p style={{ color: '#a0aec0', textAlign: 'center', padding: 40 }}>No players yet. Be the first!</p>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                {['Rank', 'Player', 'Score', 'Level', ''].map(h => (
                  <th key={h} style={styles.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {players.map((p, i) => (
                <tr key={p._id} style={{ background: i === 0 ? 'rgba(255,215,0,0.07)' : 'transparent' }}>
                  <td style={styles.td}>{MEDALS[i] || `#${i + 1}`}</td>
                  <td style={{ ...styles.td, fontWeight: 600, color: i === 0 ? '#FFD700' : '#fff' }}>{p.name}</td>
                  <td style={{ ...styles.td, color: '#FFD700', fontWeight: 700 }}>₹{p.highScore.toLocaleString()}</td>
                  <td style={{ ...styles.td, color: '#a0aec0' }}>Level {p.levelReached}</td>
                  <td style={styles.td}>
                    <button style={styles.deleteBtn} onClick={() => handleDelete(p._id)}>✕</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div style={{ display: 'flex', gap: 12, marginTop: 28, justifyContent: 'center' }}>
          <button className="btn btn-primary" onClick={() => navigate('/')}>🎮 Play Again</button>
          <button className="btn" onClick={() => navigate('/')}>🏠 Home</button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'radial-gradient(ellipse at center, #0d1b4b 0%, #0a0a2e 80%)',
    padding: 20,
  },
  card: {
    background: 'rgba(255,215,0,0.05)',
    border: '1px solid rgba(255,215,0,0.3)',
    borderRadius: 16,
    padding: '40px 32px',
    maxWidth: 600,
    width: '100%',
    boxShadow: '0 0 60px rgba(255,215,0,0.08)',
  },
  title: { color: '#FFD700', fontSize: '2.5rem', textAlign: 'center', marginBottom: 4 },
  subtitle: { color: '#a0aec0', textAlign: 'center', letterSpacing: 3, fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: 28 },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: {
    color: '#FFD700',
    fontSize: '0.75rem',
    letterSpacing: 2,
    textTransform: 'uppercase',
    padding: '8px 12px',
    borderBottom: '1px solid rgba(255,215,0,0.2)',
    textAlign: 'left',
  },
  td: {
    padding: '12px 12px',
    borderBottom: '1px solid rgba(255,255,255,0.05)',
    fontSize: '1rem',
    color: '#fff',
  },
  deleteBtn: {
    background: 'rgba(229,62,62,0.15)',
    border: '1px solid rgba(229,62,62,0.4)',
    color: '#fc8181',
    borderRadius: 4,
    padding: '4px 10px',
    cursor: 'pointer',
    fontSize: '0.75rem',
  },
};
